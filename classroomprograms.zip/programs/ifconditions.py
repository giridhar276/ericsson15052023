a = 10
b = 2
if a > b :
    print(a,'is greater than',b)
    print('Inside if')
else:
    print('B is greater than A')
    print('Inside else')
    print('Still inside else')
#### 2nd example
name = 'python'
if name.isupper():
    print('String is starting with p')
    print('its python')
else:
    print('String is not starting with p')
    print("its someother language")
print('regular code')


name = 'python'
if name.isupper():
    print('String is starting with p')
    print('its python')
elif name.islower():
    print('string is lower')
elif name.isdigit():
    print('string is digit')
else:
    print("its something else")


