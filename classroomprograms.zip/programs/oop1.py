
class Simple :
    def displayOutput(self):
        print('hello python')
    def displayInfo(self):
        print('this is just info')
    def displayvalues(self,a,b,c):
        self.a = a
        self.b = b
        self.c = c
        print(self.a, self.b , self.c)
        print(a,b,c)
    def output(self):
        print(self.a,self.b,self.c)
        
obj1 = Simple()
obj1.displayOutput()       
obj1.displayInfo()
obj1.displayvalues(10,20,30)
obj1.output()
