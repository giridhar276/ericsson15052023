# display numbers from 1 to 10
# range(start,stop,step)
for val in range(1,11):
    print(val)

for val in range(1,11,2):
    print(val)
# for loop with string
name = 'python'
for char in name:
    print(char)
# for loop with list
alist = [10,20,30,40]
for val in alist:
    print(val)
atup = (34,23,90)
for val in atup:
    print(val)