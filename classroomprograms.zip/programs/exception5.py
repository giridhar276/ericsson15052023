

try:
    ## some code
except:
    ## how to handle the exception
    
    
# 2nd style    
try:
    ## some code
except:
    ## how to handle the exception
else:
    # execute this if not exception
finally:
    #always executed
    
    
    
    
    
    
    
    
    