
alist = [10,20,30,3,4,1,100,9]
print(alist[0])
alist[0] = 100
print('After replacing', alist)


atup = (10,20,30,3,4,1,100,9)
atup[0] = 1000
print('After replacing',atup)

name = 'python'
name[0] = 'z'
print(name)