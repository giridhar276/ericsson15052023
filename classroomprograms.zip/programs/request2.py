

import requests
import json
try:
    data = requests.get('https://api.github.com/')
    if data.status_code == 200 :
        #print(type(data.text))
        data = json.loads(data.text)
        print(type(data))
        for key,value in data.items():
            print(key.ljust(20),value)
except requests.exceptions.HTTPError as err:
    print(err)
except Exception as err:
    print(err)