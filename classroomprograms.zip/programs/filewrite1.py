fobj = open('empinfo.txt','w')
fobj.write('hyderabad\n')
fobj.write('noida\n')
fobj.close()



fw = open('numbers.txt','w')
for val in range(1,10):
    fw.write(str(val) + "\n")
fw.close()



fw = open('numbers1.txt','w')
for val in range(1,10):
    fw.write(str(val) + "\n")
fw.close()


# context manager
# if any line starts with keyword with - we call it as context manager
# file gets automatically when it moves out of indentation
with open('numbers2.txt','w') as fwrite:
    for val in range(1,10):
        fwrite.write(str(val) + "\n")

        





