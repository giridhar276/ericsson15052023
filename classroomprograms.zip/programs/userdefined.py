# fixed arguments
def display(a,b):
    c = a + b
    print(c)
display(10,20)

# default arguments
def display(a = 0,b = 0,c = 0):
    print(a,b,c)
display()
display(10)
display(10,20)
display(10,20,30)

# keyword argumets
def display(c,a,b):
    print(a,b,c)
display(a = 10,b = 20 , c = 30)
def display(a,b,c,d,e,f,g,h,i,j):
    print(a,b,c)
display(10,20,30,40,50,60,70,80,90,100,324,24,52,45,243,2,3,3,34,4,3,3,3,32,2,4,6)
def display(*args): ## variable length arguments
    for val in args:
        print(val)
display(10,20,30,40,50,60,70,80,90,100,324,24,52,45,243,2,3,3,34,4,3,3,3,32,2,4,6)

def display(**kwargs):
    for key,value in kwargs.items():
        print(key,value)
display(chap1 = 10 ,chap2 = 20)

def display(*args,**kwargs):
    print("aguments:", args)
    print("----------")
    for key,value in kwargs.items():
        print(key,value)
display(10,20,'linux','scala',chap1 = 10 ,chap2 = 20)




