import pymysql      
class  DB:
    def __init__(self,host,port,user,password,database):
        self.host = host
        self.port = port
        self.user = user
        self.password  = password
        self.database = database
        
    def connect(self):
        self.conn = pymysql.connect(host= self.host,port = self.port ,user = self.user, password = self.password,database =self.database)
        print(self.conn)
    def displayRecords(self):
        self.cursor = self.conn.cursor()
        query = "select * from adultinfo"
        self.cursor.execute(query)
        for record in self.cursor.fetchall():
            print(record[0], record[1])        
obj1 = DB('localhost',3306,'root','rps@12345','details')
obj1.connect()
obj1.displayRecords()


