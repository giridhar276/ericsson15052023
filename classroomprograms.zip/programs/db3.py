
import pymysql
#step1 : establish the connection
try:
    with pymysql.connect(host='localhost',port=3306,user='root',password='rps@12345') as conn:
        print(conn)
        if conn:
            cursor = conn.cursor()
            # Step2: define the query
            query = "select * from details.adultinfo"
            #step3 execute the query
            cursor.execute(query)
            #step4 fetch the output
            for record in cursor.fetchall():
                print(record[0], record[1])
except pymysql.OperationalError as err:
    print(err)
except pymysql.IntegrityError as err:
    print(err)
except Exception as err:
    print(err)        
        