

class Employee:
    def getInfo(self,ename,address,age):
        self.ename = ename
        self.address = address
        self.age = age
        
        
    def displayInfo(self):
        print("EMpname :", self.ename)
        print('Address :',self.address)
        print('Age     :',self.age)
      
        
emp1 = Employee()
emp1.getInfo('rita','mumbai',25)
emp1.displayInfo()

