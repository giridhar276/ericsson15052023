# importing all the methods to your programspace
import math
print(math.log(2))
print(math.tan(1))

#importing with alias name
import math as m
print(m.floor(1.2))
print(m.tan(2))

# importing the required methods ONLY
from math import tan,cos,log
print(tan(2))
print(cos(1))
print(log(8))

