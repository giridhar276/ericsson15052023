book = {"chap1":10 ,"chap2":20}


print(book)
# add new key-value
book['chap3'] = 30
book['chap4'] = 40
print(book)
# acces key-value
print(book['chap1'])
#print(book['chap100'])

if 'chap100' in book:
    print(book['chap100'])
else:
    print('key doesnt exist.. creating key-value')
    book['chap100'] = 100
    print(book)

print(book)
# display keys only
print(book.keys())

for key in book.keys():
    print(key)

# display values
print(book.values())

for value in book.values():
    print(value)
    
# display key-value
for key,value in book.items():
    print(key,value)
##
print(book['chap200'])
# if key is existing ... it returns the value
# if key is not existing .. will return None
print(book.get('chap200'))
book.pop('chap100') # key-value will be removed from dictionary
print(book)
###########################################################
newbook = {"chap5":50,"chap6":60}
finalbook = {**book,**newbook}
print(finalbook)

# updating newbook with book - Here newbook will be updated
newbook.update(book)
print(newbook)
###########################################################


alist = [10,20]
blist = [30,40]
finalist = [alist,blist]
print(finalist)






