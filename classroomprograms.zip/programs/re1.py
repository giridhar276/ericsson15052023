

with open('languages.txt','r') as fobj:
    for line in fobj:
        line = line.strip()
        if 'python' in line or 'pytttthon' in line or 'pyttttttthon' in line:
            print(line)
            
# at the beginning of th string
import re
with open('languages.txt','r') as fobj:
    for line in fobj:
        line = line.strip()
        if re.search('^python',line):
            print(line)
            
# at the end
import re
with open('languages.txt','r') as fobj:
    for line in fobj:
        line = line.strip()
        if re.search('python$',line):
            print(line)
            
    
# t should exist atlesat once
import re
with open('languages.txt','r') as fobj:
    for line in fobj:
        line = line.strip()
        if re.search('pyt+hon',line):
            print(line)
            
# zero or more occurences
import re
with open('languages.txt','r') as fobj:
    for line in fobj:
        line = line.strip()
        if re.search('pyt*hon',line):
            print(line)
            
   
# . is any single character
import re
with open('languages.txt','r') as fobj:
    for line in fobj:
        line = line.strip()
        if re.search('.ython',line):
            print(line)
            
# either python or spark
import re
with open('languages.txt','r') as fobj:
    for line in fobj:
        line = line.strip()
        if re.search('(python|spark|unix)',line):
            print(line)
            
            
# t in the range of 2 and 8
import re
with open('languages.txt','r') as fobj:
    for line in fobj:
        line = line.strip()
        if re.search('pyt{2,8}hon',line):
            print(line)
                        
            
            
            