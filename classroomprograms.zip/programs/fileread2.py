

with open('adult.csv','r') as fr:
    header = fr.readline()
    for line in fr:
        line = line.strip() # remove whitespaces if any
        line = line.lower()
        print(line)
    
        
        
        
import csv
with open('adult.csv','r') as fr:
    header = fr.readline()
    # converting file object to the csv object
    reader = csv.reader(fr)
    for line in reader:
        hours_per_week = int(line[12])
        if hours_per_week < 20:
            print(line)
            
            
            
            
'''            
write a program to display to total count of male and female

Total male count  : xxx
Total female count: xx
# 
'''
import csv
malecount = 0
femalecount = 0
with open('adult.csv','r') as fr:
    header = fr.readline()
    # converting file object to the csv object
    reader = csv.reader(fr)
    for line in reader:
        line[9] = line[9].strip()
        if line[9] == 'Male':
            malecount+=1
        else:
            femalecount+=1

print('Male count :',malecount)
print('Female count:',femalecount)
        



'''
write a program to display all different workclasses as below

state-gov
private
self-emp
Federal-gov

'''

import csv
workset = set()
with open('adult.csv','r') as fr:
    header = fr.readline()
    # converting file object to the csv object
    reader = csv.reader(fr)
    for line in reader:
        workclass = line[1]
        workset.add(workclass)
        
    for work in workset:
        print(work)
        
        
        
        
import csv
workdict = dict()
with open('adult.csv','r') as fr:
    header = fr.readline()
    # converting file object to the csv object
    reader = csv.reader(fr)
    for line in reader:
        workclass = line[1]
        workdict[workclass] = 1
        
    for work in workdict:
        print(work)
        



        