
import csv
try:
    filename  = input("Enter any filename :")
    with open(filename,'r') as fr:
        # converting file object to the csv object
        reader = csv.reader(fr)
        for line in reader:
            print(line)
    output = 3 + "hello"
except FileNotFoundError as err:
    print('System defined error:',err)
    print('file not found')
except TypeError as err:
    print(err)
except ValueError as error:
    print(error)
except KeyError as error:
    print(error)
except Exception as err:
    print('some unknown error found')