

import pymysql
#step1 : establish the connection
try:
    with pymysql.connect(host='localhost',port=3306,user='root',password='rps@12345') as conn:
        print(conn)
        if conn:
            query = "insert into details.adultinfo values('{}','{}')".format('Mtech','Developer')
            #step3 execute the query
            conn.execute(query)
            #step4 make hte changes permanent
            print(conn.rowcount, "record inserted")
        
except pymysql.OperationalError as err:
    print(err)
except pymysql.IntegrityError as err:
    print(err)
except Exception as err:
    print(err)        
    