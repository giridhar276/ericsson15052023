class Simple :
    def displayOutput(self):
        print('hello python')
        
        
obj1 = Simple()
obj1.displayOutput()       

obj2 = Simple()
obj2.displayOutput() 




