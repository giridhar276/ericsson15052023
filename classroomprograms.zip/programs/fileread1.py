# read operation - reading the file line by line
with open('employees.txt','r') as fr:
    for line in fr:
        line = line.strip() # remove whitespaces if any
        print(line)
    
with open('employees.txt','r') as fr:
    for line in fr:
        line = line.strip() # remove whitespaces if any
        output = line.split(",")
        print("city:",output[3])
        
# reading all the lines of file to the list
with open('employees.txt','r') as fr:
    print(fr.readlines())
    
# reading the file to the single string
# good for reading config files but not for data files
with open('employees.txt','r') as fr:
    print(fr.read())
    
import csv
with open('employees.txt','r') as fr:
    # converting file object to the csv object
    reader = csv.reader(fr)
    for line in reader:
        print(line)
# 
import pandas
df = pandas.read_csv('employees.txt',header=None)
print(df)




        
    
