alist = [10,20,30,40,50,50,50,50,3,1,45,712,1]
# slicing list
print(alist[0:8])
print(alist[0:8:2])
print(alist[::-1])

alist.append(39)
print('After appending',alist)
alist.append(90)
print('After appending',alist)
alist.extend([29,9,21])  # adding multiple values
print('After extending',alist)
#list.insert(where to insert, what to insert)
alist.insert(1,90)
print('After inserting :',alist)
alist.pop()
print('After pop operation',alist)
alist.pop(1)
print('After pop operation',alist)
alist.remove(10) # 10 will be removed from list if existing
print('AFter removing',alist)
#alist.remove(300)
if 300 in alist:
    alist.remove(300)
else:
    print(300,"doesnt exist in the list")
    
print(alist.index(50))
getcount = alist.count(50)
print(getcount)

print(alist)
alist.sort()
print('sorted order',alist)
alist.reverse()
print('Reversing list',alist)