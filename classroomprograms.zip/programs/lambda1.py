# fixed arguments
def display(a,b):
    c = a + b
    print(c)
display(10,20)
# lambda function # inline function # nameless function
# lambda is the replacement of single liner function
#syntax #functioname = lambda variables:expression
display = lambda a,b : a + b
print(display(10,20))

getsquare = lambda x : x * x if ( x > 0) else None
print(getsquare(3))
print(getsquare(0))

maximum = lambda x,y : x if ( x >y) else y
print(maximum(1,2))




data = [' python ','   unix  ', 'spark',' scala ']
#output :[ 'python','unix','spark','scala']
output = []
for val in data:
    output.append(val.strip())
print(output)

## method1
#map(function,iterable)
def trim(x):
    return x.strip()
data = [' python ','   unix  ', 'spark',' scala ']
print(list(map(trim,data)))
#method2
trim = lambda x : x.strip()
print(list(map(trim,data)))
#method3
print(list(map(lambda x : x.strip(),data)))
# other examples
alist = ['1','2','3']
print(list(map(int,alist)))

output = ["python","unix","spark"]
print(list(map(len,output)))


data = [' python ','   unix  ', 'spark',' scala ']

# syntax: objectname = [expression  for item in list  condition]
output = [ val   for val in range(1,11)]
print(output)


output = [ val + 5   for val in range(1,11)]
print(output)

domains = ['google','oracle','microsoft']
updatedlist = [ 'www.' + val + '.com'    for val in domains]
print(updatedlist)

numlist = [  x    for x in range(20)  if x %2 == 0]
print(numlist)

# filter(function,,iterable)
numbers = [1,2,3,4,5,6,7]
#[2,4,6]
print(list(filter(lambda x : x%2==0, numbers)))
# using list comprehension
numlist = [  x    for x in numbers  if x %2 == 0]
print(numlist)


















    
    
    







