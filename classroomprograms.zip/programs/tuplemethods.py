

atup = (34,1,56,43)

print(atup)

