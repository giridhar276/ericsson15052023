

import pymysql
conn = pymysql.connect(host='localhost',port=3306,user='root',password='rps@12345',database='details')
print(conn)


conn.close()