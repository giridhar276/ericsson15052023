

class File:
    def __init__(self,file):
        self.file = file
    def displayOutput(self):
        with open(self.file) as self.obj1:
            for self.line in self.obj1:
                self.line = self.line.strip()
                print(self.line)
    

file1 = File('languages.txt')
file1.displayOutput()