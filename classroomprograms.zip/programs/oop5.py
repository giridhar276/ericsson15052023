class Employee:
    def __init__(self,ename=0,address = 0,age=0):
        self.ename = ename
        self.address = address
        self.age = age
        
        
    def displayInfo(self):
        print("EMpname :", self.ename)
        print('Address :',self.address)
        print('Age     :',self.age)
      
# constructor is invoked automatically
# constructor in python starts with __init__
emp1 = Employee('rita','mumbai',25)
emp1.displayInfo()

emp2 = Employee('rao','hyderabad',25)
emp2.displayInfo()

emp3 = Employee()
emp3.displayInfo()




emp4 = Employee('singh')
emp4.displayInfo()
print(emp4.ename)
