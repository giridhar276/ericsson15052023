


print('hello python')

val = 10
print(val)
print(1)