print('hello')
print(len('hello'))
alist = [10,20]
print(len(alist))
book = {"chap1":10,"chap2":20}
print(len(book))
print(list(range(1,10)))
print(list(range(1,10,2)))
name = 'python'
print(type(name))
print(type(book))
print(type(alist))

print(isinstance(name,str))
print(isinstance(name,list))
print(isinstance(alist,list))
print(isinstance(alist,dict))

print(max(alist))
print(min(alist))
print(sum(alist))

name = input('Enter any name:')
print(name)

print(dir(name))


atup = (10,20,30)
alist = list(atup)
print(alist)
print(list(name))
