name = 'python programming'
print(name)
print('I love unix')
print('I love',name)
# string[start:stop:incremental]  # string slicing
print(name[0]) #p
print(name[1]) #y
print(name[0:400])
print(name[2:9])
print(name[0:18:1])
print(name[0:18:2])
print(name[1:18:2])
print(name[0:18:3])
print(name[:])  # python programming
print(name[::])
print(name[:4])
print(name[7:])
print(name[4:9:2])
print(name[-1])
print(name[-5:-2])
print(name[::]) # python programming
print(name[::-1])

print(name[-2:-5:-1])


name = 'python programming'
aname = 'a,b,c,d'
print(name.capitalize())
print(name.title())
print(name.upper())
print(name.lower())
print(name.count('P'))
print(name.split(' '))
print(aname.split(","))
print(name.replace('python','scala'))
print(name.isupper())
print(name.islower())
print(name.startswith('z'))
print(name.startswith('p'))
bname = '  python '
print(len(bname))
print(len(bname.strip()))
print(len(bname.rstrip()))
print(len(bname.lstrip()))
string = "I love {} and {}"  # place holders
print(string.format('unix','java'))
print(string.format(1,2))
string = "I love {2} and {1}"  # place holders
print(string.format('unix','java'))
print(string.format(1,2))




print('python')
print('scala')

print('python',end=' ')
print('java',end=' ')
print('ruby')








