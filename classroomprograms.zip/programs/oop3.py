

class Simple :
    def displayOutput(self):
        print('hello python')
        
    def displayValues(self,a,b):
        self.a = a
        self.b = b
        
    def finalOuptut(self):
        print(self.a,self.b)
        
obj1 = Simple()
obj1.displayOutput()    
obj1.displayValues(10,20)  
obj1.finalOuptut() 

obj2 = Simple()
obj2.displayOutput() 
obj2.displayValues(10,20)  
obj2.finalOuptut() 