'''
define list as below

lang  = ["spark","spark","spark","java","unix","unix","python","python"]

write a program to display each Unique iteam and the no.of times it is repeated

Spark : 3 times
java    :  1 time
unix   :  2 times
'''

lang  = ["spark","spark","spark","java","unix","unix","python","python"]

for item in set(lang):
    print(item.ljust(10) , lang.count(item),"times")