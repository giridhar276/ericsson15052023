import pymysql
#step1 : establish the connection
with pymysql.connect(host='localhost',port=3306,user='root',password='rps@12345',database='details') as conn:
    print(conn)
    if conn:
        cursor = conn.cursor()
        # Step2: define the query
        query = "select * from adultinfo"
        #step3 execute the query
        cursor.execute(query)
        #step4 fetch the output
        for record in cursor.fetchall():
            print(record[0], record[1])
        
        