
import requests
import bs4
try:
    data = requests.get('https://www.google.com/')
    if data.status_code == 200 :
        print(data.text)
except requests.exceptions.HTTPError as err:
    print(err)
except Exception as err:
    print(err)