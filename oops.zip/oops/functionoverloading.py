
#fixed args
def display(a,b):
    print(a,b,c)

display(10,20)





#function overloading
def display(a = 0,b = 0,c = 1):
    print(a,b,c)


display()      # 0 0 1
display(10)    # 10 0 1
display(10,20) # 10 20 1
display(10,20,30) # 10 20 30