


class MethodNotAllowed(Exception):
    pass


class Bike:
    def __init__(self, description, condition, sale_price, cost=0):
        self.cost = cost
        self.sale_price = sale_price
        self.condition = condition
        self.description = description

        self.sold = False

    def update_sale_price(self, new_sale_price):
        if self.sold:
            raise MethodNotAllowed("You can't update the sale price of a bike that's been sold")
        self.sale_price = new_sale_price
        
    def sell(self):
        self.sold = True
        profit = self.sale_price - self.cost
        return profit

    def service(self, cost, new_sale_price=None, new_condition=None):
        self.cost += cost
        if new_sale_price:
            self.update_sale_price(new_sale_price)
        if new_condition:
            self.condition = new_condition


if __name__ == '__main__':
    my_bike = Bike("Red Releigh cruiser", 'GOOD', 450, 50)

    my_bike.update_sale_price(400)

    profit = my_bike.sell()

    print("Final profit :", profit)

    #my_bike.update_sale_price(1000)