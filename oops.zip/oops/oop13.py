


class Student:
    def __init__(self,grd):
        self.grade=grd
    def __gt__(self, other):
        return self.grade>other.grade


John=Student(11)
Jack=Student(10)
print(John>Jack)



